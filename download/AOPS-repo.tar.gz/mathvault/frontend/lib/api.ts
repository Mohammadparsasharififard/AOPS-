/**
 * Lightweight API client — uses /api proxy in dev, NEXT_PUBLIC_API_BASE in prod.
 * All fetches use Next.js rewrites so the frontend stays offline-friendly:
 * if the API isn't reachable, we show the offline message at the page level.
 */

export interface StatsResponse {
  contests: number;
  problems: number;
  countries: number;
  pages: number;
  assets: number;
  discussions: number;
  posts: number;
  last_sync_at: string | null;
  next_sync_at: string | null;
  sync_interval_hours: number;
}

export interface Contest {
  id: string;
  name: string;
  slug: string;
  category?: string | null;
  is_international: boolean;
  country?: string | null;
  year_count: number;
  last_synced?: string | null;
}

export interface Problem {
  id: string;
  number?: string | null;
  title?: string | null;
  contest_name?: string | null;
  contest_slug?: string | null;
  year?: number | null;
  archive_status: string;
}

export interface ProblemDetail extends Problem {
  statement_html?: string | null;
  statement_text?: string | null;
  source_url?: string | null;
  archive_url?: string | null;
  solution_available: boolean;
  discussion_available: boolean;
  tags: string[];
  prev_id?: string | null;
  next_id?: string | null;
  position?: number | null;
  total_in_contest?: number | null;
}

export interface SearchHit {
  doc_type: string;
  ref_id: string;
  title?: string | null;
  snippet?: string | null;
  contest_name?: string | null;
  year?: number | null;
  country?: string | null;
  tags?: string | null;
  url?: string | null;
  rank: number;
}

async function apiGet<T>(path: string): Promise<T> {
  const res = await fetch(`/api${path}`, {
    headers: { "Accept": "application/json" },
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error(`API ${res.status}: ${await res.text()}`);
  }
  return (await res.json()) as T;
}

export const api = {
  stats: () => apiGet<StatsResponse>("/stats"),
  contests: (params: { international?: boolean; country_slug?: string } = {}) => {
    const q = new URLSearchParams();
    if (params.international !== undefined) q.set("international", String(params.international));
    if (params.country_slug) q.set("country_slug", params.country_slug);
    return apiGet<Contest[]>(`/contests?${q.toString()}`);
  },
  contest: (slug: string) => apiGet<any>(`/contests/${slug}`),
  contestYear: (slug: string, year: number) => apiGet<any>(`/contests/${slug}/${year}`),
  countries: () => apiGet<any[]>("/countries"),
  country: (slug: string) => apiGet<any>(`/countries/${slug}`),
  problems: (params: { q?: string; tag?: string; contest_slug?: string; year?: number; limit?: number; offset?: number } = {}) => {
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null) q.set(k, String(v));
    }
    return apiGet<Problem[]>(`/problems?${q.toString()}`);
  },
  problem: (id: string) => apiGet<ProblemDetail>(`/problems/${id}`),
  problemDiscussion: (id: string) => apiGet<any>(`/problems/${id}/discussion`),
  search: (q: string, doc_type?: string, limit = 20, offset = 0) => {
    const params = new URLSearchParams({ q, limit: String(limit), offset: String(offset) });
    if (doc_type) params.set("doc_type", doc_type);
    return apiGet<SearchHit[]>(`/search?${params.toString()}`);
  },
  admin: {
    syncStatus: (user: string, pass: string) =>
      fetch(`/api/admin/sync-status`, {
        headers: { Authorization: "Basic " + btoa(`${user}:${pass}`) },
      }).then((r) => (r.ok ? r.json() : Promise.reject(r))),
    runSync: (user: string, pass: string) =>
      fetch(`/api/admin/run-sync`, {
        method: "POST",
        headers: { Authorization: "Basic " + btoa(`${user}:${pass}`) },
      }).then((r) => (r.ok ? r.json() : Promise.reject(r))),
  },
};
